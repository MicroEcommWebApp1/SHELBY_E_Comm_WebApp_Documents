package com.example.Product_Service.dto;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.Set;

@Data
public class ProductDTO {

    private Long productId;
    private int sellerId;
    private String name;
    private String sellerEmailID;
    private String description;
    private String thumbnail;
    private Set<Long> productImages;
    private String tags;
    private double price;
    private int quantity;
    private String category;
    private String subcategory1;
    private String subcategory2;
    private LocalDateTime createdAt;

}
