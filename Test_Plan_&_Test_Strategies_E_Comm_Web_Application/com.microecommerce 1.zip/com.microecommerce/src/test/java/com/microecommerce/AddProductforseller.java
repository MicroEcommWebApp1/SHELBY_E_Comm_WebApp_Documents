package com.microecommerce;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class AddProductforseller {
	@Test

		public void Micro() throws InterruptedException {
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--remote-allow-origins=*");
			
			    System.setProperty("webdriver.chrome.driver", "C:\\Users\\gbhavya\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
			    WebDriver driver = new ChromeDriver(options);
			   // driver.get("http://localhost:4200/login");
			    driver.get("http://localhost:4200/sellerdashboard");
				 driver.manage().window().maximize();
				 Thread.sleep(3000);
				 driver.findElement(By.xpath("/html/body/app-root/div/div/app-sellerdashboard/div/div[1]/button/a")).click();
				 Thread.sleep(3000);
				 driver.findElement(By.xpath("//*[@id=\"name\"]")).sendKeys("women saree");
				 Thread.sleep(3000);
				 driver.findElement(By.xpath("//*[@id=\"description\"]")).sendKeys("silk saree");
				 Thread.sleep(3000);
				 driver.findElement(By.xpath("//*[@id=\"price\"]")).sendKeys("10");
				 Thread.sleep(3000);
				 driver.findElement(By.xpath("//*[@id=\"quantity\"]")).sendKeys("5");
				 Thread.sleep(3000);
				 Select dropdown = new Select(driver.findElement(By.id("APPAREL")));
				 dropdown.selectByVisibleText("APPAREL");

	}

}
