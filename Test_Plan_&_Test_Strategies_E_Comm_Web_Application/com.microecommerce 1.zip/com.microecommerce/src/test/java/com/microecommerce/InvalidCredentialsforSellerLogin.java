package com.microecommerce;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

public class InvalidCredentialsforSellerLogin {
	@Test

	public static void main(String[] args) throws InterruptedException {
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
    System.setProperty("webdriver.chrome.driver", "C:\\Users\\gbhavya\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
    WebDriver driver = new ChromeDriver(options);
//	 driver.get("http://localhost:4200/mainpage");
//	 driver.manage().window().maximize();
	 
	 driver.get("http://localhost:61217/");
	 driver.manage().window().maximize();
	Thread.sleep(3000);
	 driver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys("");
	 Thread.sleep(3000);
	 driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("");
	 Thread.sleep(3000);
	 driver.findElement(By.xpath("/html/body/app-root/div/div/app-login/div/div/form/input")).click();
	 Thread.sleep(3000);
	// String u=driver.getCurrentUrl();
	 
	 driver.close();

	}

}
