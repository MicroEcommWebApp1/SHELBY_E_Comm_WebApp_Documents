package com.microecommerce;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Checkfeildsforforgotpasswordinseller {
	@Test

		public void Micro() throws InterruptedException {
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--remote-allow-origins=*");
			
				
			    System.setProperty("webdriver.chrome.driver", "C:\\Users\\gbhavya\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
			    WebDriver driver = new ChromeDriver(options);
			//	 driver.get("http://localhost:4200/mainpage");
			//	 driver.manage().window().maximize();
				 
				 driver.get("http://localhost:4200/login");
				 driver.manage().window().maximize();
				 Thread.sleep(3000);
				 Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[3]/a")).isDisplayed(), true);
			     Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"email\"]")).isDisplayed(), true);
				 Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"password\"]")).isDisplayed(), true);
				// Assert.assertEquals(driver.findElement(By.xpath("/html/body/app-root/app-login/div[2]/div/div/form/div[3]/a")).isDisplayed(), true);
				 driver.findElement(By.xpath("/html/body/app-root/app-forgot-password/div[2]/div/button")).click();
				 Thread.sleep(3000);
				 

	}

}
