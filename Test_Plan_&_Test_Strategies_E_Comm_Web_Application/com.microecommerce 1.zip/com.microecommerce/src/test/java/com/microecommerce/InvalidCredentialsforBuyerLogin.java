package com.microecommerce;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

public class InvalidCredentialsforBuyerLogin {
	@Test

		public void Micro() throws InterruptedException {
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--remote-allow-origins=*");
			
			    System.setProperty("webdriver.chrome.driver", "C:\\Users\\gbhavya\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
			    WebDriver driver = new ChromeDriver(options);
			    driver.get("http://localhost:4200/login");
				 driver.manage().window().maximize();
				 Thread.sleep(3000);
				 driver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys("venugopalalapati123@gmail.com");
				 Thread.sleep(3000);
				 driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("Venu@15456");
				 Thread.sleep(3000);
				 driver.findElement(By.xpath("/html/body/app-root/app-login/div/div/div[2]/form/div[4]")).click();
				 Thread.sleep(3000);

				 driver.close();

	}

}
