package Seller;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class sellerdashboardaddproduct {
	@Test
	
	
	public void Micro() throws InterruptedException {
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
    System.setProperty("webdriver.chrome.driver", "C:\\Users\\gbhavya\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
    WebDriver driver = new ChromeDriver(options);
	 
	 driver.get("http://localhost:4200");
	 driver.manage().window().maximize();
	 Thread.sleep(3000);
	 driver.findElement(By.xpath("/html/body/app-root/div/app-nav-bar/nav/a[6]")).click();
	 Thread.sleep(3000);
	 driver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys("guntamadugubhavya@gmail.com");
	 Thread.sleep(3000);
	 driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("Bhavya@123");
	 Thread.sleep(3000);
	 driver.findElement(By.xpath("/html/body/app-root/div/div/app-login/div/div/form/input")).click();
	 Thread.sleep(3000);
	 driver.findElement(By.xpath("/html/body/div/div/div[6]/button[1]")).click();
	 Thread.sleep(3000);
	 driver.findElement(By.xpath("/html/body/app-root/div/div/app-sellerdashboard/div/div[1]/button")).click();
	 Thread.sleep(3000);
	 driver.findElement(By.xpath("//*[@id=\"name\"]")).sendKeys("kurthi");
	 Thread.sleep(3000);
	 driver.findElement(By.xpath("//*[@id=\"description\"]")).sendKeys("dress");
	
	 Thread.sleep(3000);
	 
	 WebElement Price =driver.findElement(By.xpath("//*[@id=\"price\"]"));
	 Price.clear();
	 driver.findElement(By.xpath("//*[@id=\"price\"]")).sendKeys("2");
	 Thread.sleep(3000);
	 WebElement Quantity =driver.findElement(By.xpath("//*[@id=\"quantity\"]"));
	 Quantity.clear();
	 driver.findElement(By.xpath("//*[@id=\"quantity\"]")).sendKeys("1");
	 Thread.sleep(3000);
	//Category 
	
	WebElement dropdownElement=driver.findElement(By.xpath("//*[@id=\"category\"]"));
	Select dropdown=new Select(dropdownElement);
	dropdown.selectByVisibleText("APPAREL");
	String selectedOption=dropdown.getFirstSelectedOption().getText();
	if
	(selectedOption.equals("APPAREL")) { 
	System.out.println("APPAREL is selected"); }
	 
	//Subcategory1
	
	WebElement dropdownElement1=driver.findElement(By.xpath("//*[@id=\"subcategory1\"]"));
	Select dropdown1=new Select(dropdownElement1);
	dropdown1.selectByVisibleText("Women");
	String selectedOption1=dropdown1.getFirstSelectedOption().getText();
	if
	(selectedOption1.equals("Women")) { 
	System.out.println("Women is selected"); }
	
	
	 //Subcategory2:
	

	WebElement dropdownElement2=driver.findElement(By.xpath("//*[@id=\"subcategory2\"]"));
	Select dropdown2=new Select(dropdownElement2);
	dropdown2.selectByVisibleText("Kurthi");
	String selectedOption2=dropdown2.getFirstSelectedOption().getText();
	if
	(selectedOption2.equals("Kurthi")) { 
	System.out.println("Kurthi is selected"); }
	
	  
	// driver.findElement(By.xpath("//*[@id=\"category\"]")).sendKeys("APPAREL");
	// Thread.sleep(3000);
	 driver.findElement(By.xpath("//*[@id=\"thumbnail\"]")).sendKeys("https://www.nalli.com/media/catalog/product/b/e/be1268785_m.jpg?width=560&height=560&optimize=high&fit=bounds");
	 Thread.sleep(3000);
	 driver.findElement(By.xpath("/html/body/app-root/div/div/app-addproduct/div/div/form/div[2]/div[1]/input")).sendKeys("C:\\Users\\gbhavya\\Downloads\\image\\kurthi.jpg");
	 Thread.sleep(3000);
	 
	 driver.findElement(By.xpath("/html/body/app-root/div/div/app-addproduct/div/div/form/button")).click();
	 Thread.sleep(3000);
	 driver.findElement(By.xpath("/html/body/div/div/div[6]/button[1]")).click();
	 Thread.sleep(3000);
	 
	}

}
