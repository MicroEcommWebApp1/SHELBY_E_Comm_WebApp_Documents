package Seller;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

public class RegistrationPage {
	
@Test

	
	public void VerfiyComponents() throws InterruptedException {
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		
			
		    System.setProperty("webdriver.chrome.driver\", \"C:\\\\Users\\\\gbhavya\\\\Downloads\\\\chromedriver-win64\\\\chromedriver-win64\\\\chromedriver.exe", null);
		
		    WebDriver driver = new ChromeDriver(options);
			driver.get("http://localhost:4200/");
			driver.manage().window().maximize();
			Thread.sleep(3000);
			driver.findElement(By.xpath("/html/body/app-root/div/app-nav-bar/nav/a[3]")).isDisplayed();
			Thread.sleep(3000);
			driver.findElement(By.xpath("/html/body/app-root/div/app-nav-bar/nav/a[3]")).click();
			Thread.sleep(3000);
			driver.findElement(By.xpath("//input[@id='uname']")).isDisplayed();
			driver.findElement(By.xpath("//input[@id='email']")).isDisplayed();
			driver.findElement(By.xpath("//input[@id='cname']")).isDisplayed();
			driver.findElement(By.xpath("//input[@id='GSTINNumber']")).isDisplayed();
			driver.findElement(By.xpath("//input[@id='address']")).isDisplayed();
			driver.findElement(By.xpath("//input[@id='password']")).isDisplayed();
			driver.findElement(By.xpath("//input[@id='phoneNumber']")).isDisplayed();
			driver.findElement(By.xpath("//input[@type='submit']")).isDisplayed();
			driver.close();
			
			
	}
			
			
		}




