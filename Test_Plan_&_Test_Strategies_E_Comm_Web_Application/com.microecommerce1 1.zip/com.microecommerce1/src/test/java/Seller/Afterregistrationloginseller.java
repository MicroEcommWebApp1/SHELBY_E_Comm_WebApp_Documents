package Seller;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

public class Afterregistrationloginseller {
@Test

	
	public void Vaildinputs() throws InterruptedException {
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		
			
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\gbhavya\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		
		    WebDriver driver = new ChromeDriver(options);
			driver.get("http://localhost:4200");
			Thread.sleep(3000);
			driver.findElement(By.xpath("/html/body/app-root/div/app-nav-bar/nav/a[6]")).click();
			driver.findElement(By.xpath("//input[@id='email']")).sendKeys("guntamadugubhavya@gmail.com");
			driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Bhavya@123");
		//	driver.findElement(By.xpath("/html/body/app-root/div/div/app-login/div/div/form/input")).isDisplayed();
			//driver.close();
			driver.findElement(By.xpath("//*[@id=\"validationCheck\"]/input[3]")).click();
			
}
}
