package Seller;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

public class Registrationseller {
@Test

	
	public void Vaildinputs() throws InterruptedException {
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		
			
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\gbhavya\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		
		    WebDriver driver = new ChromeDriver(options);
			driver.get("http://localhost:4200");
			driver.manage().window().maximize();
			 Thread.sleep(3000);
		//	driver.findElement(By.xpath("/html/body/app-root/div/app-nav-bar/nav/a[3]")).isDisplayed();
			Thread.sleep(3000);
			driver.findElement(By.xpath("/html/body/app-root/div/app-nav-bar/nav/a[7]")).click();
			Thread.sleep(3000);
			driver.findElement(By.xpath("//input[@id='uname']")).sendKeys("Bhavya");
			Thread.sleep(3000);
			driver.findElement(By.xpath("//input[@id='email']")).sendKeys("guntamadugubhavya@gmail.com");
			Thread.sleep(3000);
			driver.findElement(By.xpath("//input[@id='cname']")).sendKeys("bhavya Fabrics");
			Thread.sleep(3000);
			driver.findElement(By.xpath("//input[@id='GSTINNumber']")).sendKeys("78ABCDE6789U9ZH");
			Thread.sleep(3000);
			driver.findElement(By.xpath("//input[@id='address']")).sendKeys("#03 LA sagaram naidupeta");
			Thread.sleep(3000);
			driver.findElement(By.xpath("//input[@id='phoneNumber']")).sendKeys("1234567891");
			Thread.sleep(3000);
			driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Bhavya@123");
			Thread.sleep(3000);
			
			driver.findElement(By.xpath("/html/body/app-root/div/div/app-register/div/div/form/div[8]/input")).click();
			Thread.sleep(3000);
			driver.findElement(By.xpath("/html/body/app-root/div/app-nav-bar/nav/a[7]")).click();
			Thread.sleep(3000);
		//	driver.close();
			
			
	}

}
