package Seller;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

public class registrationsellerinvalid {
@Test

	
	public void Vaildinputs() throws InterruptedException {
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		
			
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\gbhavya\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		
		    WebDriver driver = new ChromeDriver(options);
			driver.get("http://localhost:4200/");
			Thread.sleep(3000);
			//driver.findElement(By.xpath("/html/body/app-root/div/app-nav-bar/nav/a[3]")).isDisplayed();
			Thread.sleep(3000);
			driver.findElement(By.xpath("/html/body/app-root/div/app-nav-bar/nav/a[7]")).click();
			Thread.sleep(3000);
			driver.findElement(By.xpath("//input[@id='uname']")).sendKeys("1234567");
			Thread.sleep(3000);
			driver.findElement(By.xpath("//input[@id='email']")).sendKeys("bhavanaprabhakar");
			Thread.sleep(3000);
			driver.findElement(By.xpath("//input[@id='cname']")).sendKeys("bhavana Fabrics123");
			Thread.sleep(3000);
			driver.findElement(By.xpath("//input[@id='GSTINNumber']")).sendKeys("12345");
			Thread.sleep(3000);
			driver.findElement(By.xpath("//input[@id='address']")).sendKeys("");
			Thread.sleep(3000);
			driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Bhavana");
			Thread.sleep(3000);
			driver.findElement(By.xpath("//input[@id='phoneNumber']")).sendKeys("8654");
			Thread.sleep(3000);
			driver.findElement(By.xpath("//input[@type='submit']")).isDisplayed();
			driver.close();
			
			
	}

}
