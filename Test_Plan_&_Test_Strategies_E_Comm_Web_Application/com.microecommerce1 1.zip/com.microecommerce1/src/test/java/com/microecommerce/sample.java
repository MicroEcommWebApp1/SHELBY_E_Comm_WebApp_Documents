package com.microecommerce;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

public class sample {
@Test
	
	public void Micro() throws InterruptedException {
	ChromeOptions options = new ChromeOptions();
	options.addArguments("--remote-allow-origins=*");
	
		
	    System.setProperty("webdriver.chrome.driver", "C:\\Users\\bprabhakar3\\Downloads\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
	
	    WebDriver driver = new ChromeDriver(options);
		driver.get("http://localhost:52167/mainpage");
		
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/app-root/app-mainpage/main/div/div/div[1]/h2")).isDisplayed();
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("/html/body/app-root/app-mainpage/main/div/div/div[1]/button")).click();
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("/html/body/app-root/app-mainpage/header/nav/div[3]/a[1]/i")).click();
		Thread.sleep(3000);
	      driver.findElement(By.xpath("/html/body/app-root/app-cart/main/div/div[1]/div/div[1]/h2")).isDisplayed();Thread.sleep(3000);
		 driver.findElement(By.xpath("/html/body/app-root/app-cart/main/div/div[1]/div/div[2]/button[2]")).click();Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/app-root/app-cart/main/div/div[1]/div/div[2]/button[1]")).click();Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/app-root/app-cart/main/div/div[1]/div/div[3]/button")).click();Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/app-root/app-cart/header/nav/div[1]/a/img")).click();Thread.sleep(3000);
	   driver.close();
	}

}
