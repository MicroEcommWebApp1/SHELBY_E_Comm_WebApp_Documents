package BuyerTestSuites;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class registerbuyerinvaliddetails {
	
	public void VerfiyComponents() throws InterruptedException {
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		
			
		    System.setProperty("webdriver.chrome.driver", "C:\\Users\\bprabhakar3\\Downloads\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
		
		    WebDriver driver = new ChromeDriver(options);
			driver.get("http://localhost:4200");
			Thread.sleep(3000);
			driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[3]/a")).click();
			Thread.sleep(3000);
			driver.findElement(By.xpath("/html/body/app-root/app-login/div/div/div[2]/form/div[4]/p/a")).click();
			Thread.sleep(3000);
		    driver.findElement(By.xpath("//input[@id='name']")).sendKeys("123456");
			Thread.sleep(3000);
			driver.findElement(By.xpath("//input[@id='email']")).sendKeys("bhava.com");
			Thread.sleep(3000);
			
			driver.findElement(By.xpath("//input[@id='password']")).sendKeys("bhavan");
			Thread.sleep(3000);
			driver.findElement(By.xpath("//input[@id='mobilenumber']")).sendKeys("91411");
			Thread.sleep(3000);
			driver.findElement(By.xpath("//input[@id='form2Example3c']")).click();
			Thread.sleep(3000);
		    driver.findElement(By.xpath("/html/body/app-root/app-register/div/div/div[2]/form/div[7]\r\n")).isDisplayed();
		    driver.close();
	}

}
