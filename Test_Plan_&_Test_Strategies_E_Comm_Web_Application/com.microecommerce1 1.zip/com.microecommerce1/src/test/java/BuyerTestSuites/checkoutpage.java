package BuyerTestSuites;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

public class checkoutpage {
@Test
	
	public void Micro() throws InterruptedException {
	ChromeOptions options = new ChromeOptions();
	options.addArguments("--remote-allow-origins=*");
	
		
	 System.setProperty("webdriver.chrome.driver", "C:\\Users\\gbhavya\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
	    WebDriver driver = new ChromeDriver(options);
	    driver.get("http://localhost:4200/");
	    driver.manage().window().maximize();
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/app-root/app-mainpage/main/div/div/div[1]/button/span")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/app-root/app-mainpage/header/nav/div[3]/a[1]/i")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/app-root/app-cart/main/div/div[1]/div")).isDisplayed();
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/app-root/app-cart/main/button")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='name']")).isDisplayed();
		driver.findElement(By.xpath("//input[@id='cardNumber']")).isDisplayed();
		driver.findElement(By.xpath("//*[@id=\"expiryMonth\"]")).isDisplayed();
		driver.findElement(By.xpath("//*[@id=\"expiryYear\"]")).isDisplayed();
		driver.findElement(By.xpath("//*[@id=\"cvv\"]")).isDisplayed();
		driver.findElement(By.xpath("//*[@id=\"phoneNumber\"]")).isDisplayed();
		driver.findElement(By.xpath("//*[@id=\"address\"]")).isDisplayed();
		driver.findElement(By.xpath("/html/body/app-root/app-checkout/div[3]/form/button")).isDisplayed();
		
		
}

}
