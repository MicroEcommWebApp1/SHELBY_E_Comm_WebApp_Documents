package BuyerTestSuites;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.Test;

public class HomepageBuyer {
@Test
	
	public void Micro() throws InterruptedException {
	ChromeOptions options = new ChromeOptions();
	options.addArguments("--remote-allow-origins=*");
	
		
	    System.setProperty("webdriver.chrome.driver", "C:\\Users\\bprabhakar3\\Downloads\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
	
	    WebDriver driver = new ChromeDriver(options);
		driver.get("http://localhost:4200/mainpage");
		
		Thread.sleep(10000);
		//product 1
		Assert.assertEquals(driver.findElement(By.xpath("/html/body/app-root/app-mainpage/main/div/div/div[1]/h2")).isDisplayed(),true);
		//shopping cart button
		Assert.assertEquals(driver.findElement(By.xpath("/html/body/app-root/app-mainpage/header/nav/div[3]/a[1]/i")).isDisplayed(),true);
		//home button
		Assert.assertEquals(driver.findElement(By.xpath("/html/body/app-root/app-cart/header/nav/div[1]/a/img")).isDisplayed(),true);
		//search 
		Assert.assertEquals(driver.findElement(By.xpath("/html/body/app-root/app-mainpage/header/nav/div[2]/input")).isDisplayed(),true);
		//profile button
		Assert.assertEquals(driver.findElement(By.xpath("/html/body/app-root/app-mainpage/header/nav/div[3]/a[2]/i")).isDisplayed(),true);
		driver.close();
		
}
}
