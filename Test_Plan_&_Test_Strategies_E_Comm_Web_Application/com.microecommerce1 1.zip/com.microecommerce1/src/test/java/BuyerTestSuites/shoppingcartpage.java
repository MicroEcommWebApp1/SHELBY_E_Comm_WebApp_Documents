package BuyerTestSuites;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

public class shoppingcartpage {
	
@Test
	
	public void Micro() throws InterruptedException {
	ChromeOptions options = new ChromeOptions();
	options.addArguments("--remote-allow-origins=*");
	
		
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\gbhavya\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
	
	    WebDriver driver = new ChromeDriver(options);
		driver.get("http://localhost:4200/mainpage");	
		 driver.manage().window().maximize();
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/app-root/app-mainpage/main/div/div/div[1]/button/span")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("driver.findElement(By.xpath(\"/html/body/app-root/app-mainpage/main/div/div/div[1]/button/span\")).click();")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/app-root/app-cart/main/div/div[1]/div")).isDisplayed();
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/app-root/app-cart/main/button")).click();
		Thread.sleep(3000);
		
		
}


}
