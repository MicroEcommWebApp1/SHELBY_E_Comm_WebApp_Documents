package BuyerTestSuites;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

public class shopbutton {
	@Test

	
		public void VerfiyComponents() throws InterruptedException {
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--remote-allow-origins=*");
			
				
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\gbhavya\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
			
			    WebDriver driver = new ChromeDriver(options);
				driver.get("http://localhost:4200/");
				 driver.manage().window().maximize();
				Thread.sleep(3000);
				 driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[3]/a")).click();
				 Thread.sleep(3000);
				 driver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys("guntamadugubhavya@gmail.com");
				 Thread.sleep(3000);
				 driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("Bhavya@123");
				 Thread.sleep(3000);
				 driver.findElement(By.xpath("/html/body/app-root/app-login/div[2]/div/div/form/div[4]/button")).click();
				 Thread.sleep(3000);
				//driver.findElement(By.xpath("/html/body/app-root/app-mainpage/app-buyernavbar/header/nav/div[2]/a[1]")).click();
				// Thread.sleep(3000);
				 driver.findElement(By.xpath("/html/body/div/div/div[6]/button[1]")).click();
				 Thread.sleep(3000);
				 driver.findElement(By.xpath("/html/body/app-root/app-mainpage/app-buyernavbar/header/nav/div[2]/a[1]")).click();
				 Thread.sleep(3000);
				 Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"product1\"]/div/div[1]/div[1]/img")).isDisplayed(), true);
				 
				 
				 
				 WebElement element=driver.findElement(By.xpath("//*[@id=\"product1\"]/div/div[1]/div[2]/button[1]"));
					JavascriptExecutor js=(JavascriptExecutor)driver;
					js.executeScript("arguments[0].scrollIntoView()",element);
				 Thread.sleep(3000);
				 
				 driver.findElement(By.xpath("//*[@id=\"product1\"]/div/div[1]/div[2]/button[2]/span")).click();
			 	Thread.sleep(3000);
			 	
			 	driver.findElement(By.xpath("//*[@id=\"product1\"]/div/div[2]/div[2]/button[2]/span")).click();
			 	Thread.sleep(3000);
				 
				 
		//		driver.findElement(By.xpath("//*[@id=\"product1\"]/div/div[1]/div[2]/button[1]/i")).click();
			//	Thread.sleep(3000);
				
				
				
				
		//		 Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"prodetails\"]/div[2]/h2[1]")).isDisplayed(), true);
			//	 Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"prodetails\"]/div[2]/h6")).isDisplayed(), true);
				// Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"prodetails\"]/div[2]/h2[2]")).isDisplayed(), true);
				  
				// driver.findElement(By.xpath("//*[@id=\"prodetails\"]/div[2]/select")).click();
	//			 Thread.sleep(3000);
		//		 driver.findElement(By.xpath("//*[@id=\"prodetails\"]/div[2]/select/option[3]")).click();
			//	 Thread.sleep(3000);
				 
				 
			
	}

}
