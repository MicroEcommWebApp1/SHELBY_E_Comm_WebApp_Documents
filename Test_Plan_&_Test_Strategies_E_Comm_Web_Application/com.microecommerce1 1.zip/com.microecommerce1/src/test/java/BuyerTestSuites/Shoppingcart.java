package BuyerTestSuites;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;


public class Shoppingcart {
	
@Test
	
	public void Micro() throws InterruptedException {
	ChromeOptions options = new ChromeOptions();
	options.addArguments("--remote-allow-origins=*");
	
		
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\gbhavya\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
	
	    
	    WebDriver driver = new ChromeDriver(options);
		driver.get("http://localhost:4200");
		 driver.manage().window().maximize();
		
		Thread.sleep(10000);
		driver.findElement(By.xpath("/html/body/app-root/app-mainpage/main/div/div/div[1]/h2")).isDisplayed();
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("/html/body/app-root/app-mainpage/main/div/div/div[1]/button")).click();
		
		driver.findElement(By.xpath("/html/body/app-root/app-mainpage/header/nav/div[3]/a[1]/i")).click();
		
	      driver.findElement(By.xpath("/html/body/app-root/app-cart/main/div/div[1]/div/div[1]/h2")).isDisplayed();
		 driver.findElement(By.xpath("/html/body/app-root/app-cart/main/div/div[1]/div/div[2]/button[2]")).click();
		 driver.findElement(By.xpath("/html/body/app-root/app-cart/main/div/div[1]/div/div[2]/button[1]")).click();
		 driver.findElement(By.xpath("/html/body/app-root/app-cart/main/div/div[1]/div/div[3]/button")).click();
		 driver.findElement(By.xpath("/html/body/app-root/app-cart/header/nav/div[1]/a/img")).click();
	    driver.close();
	}


}
